I don't know but hi Lord_Vicky
It's me Khang Nguyen.
This is for Samsung phones only.
Nevermind. there are 2 files included here in this zip file

------------Installing-----------
Copy and paste them into /system/media then set permissions of those 2 to -rw-r--r--
---------------------------------

The animation is slow and a little bit...laggy because of low fps ya know.
But here's a fix

------------Fix_Low_FPS----------
Modify system/build.prop
add this line
	boot.fps=30
and save it
done!
---------------------------------

Love your work of Razerite btw <3